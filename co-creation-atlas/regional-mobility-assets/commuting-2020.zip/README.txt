2020年国勢調査 通勤通学・交通手段の再整理
確認日:2026-11-04

15歳以上通勤者（自宅外就業者）と15歳以上通学者を対象。6-2+6-3を加算し17-2常住地総数と全5地域で照合。
6-1は15歳未満通学者を含むため同一分母比較に使用せず、別枠参考値のみ。
交通手段はふだんの利用。17-2の自家用車のみは複合利用を含まない。徒歩のみ、1種類、2種類、3種類以上、不詳は排他的だが、1種類/2種類の内訳と小計を同時加算してはならない。
構成比は不詳除外を主値とし、不詳込み総数分母も併記。分子・分母と数式を記載。
表の記号-は該当数値なし。ODの計算では0扱い、原記号も保存。
2020年の歴史的構造であり現在の需要・朝ピーク・渋滞・共同バス需要を示さない。
同一母集団でもODと交通手段のクロス集計ではないため、OD人数×地域自家用車率でそのODの自動車通勤人数を推計しない。

出典:
https://www.e-stat.go.jp/stat-search/files?stat_infid=000032214690
https://www.e-stat.go.jp/stat-search/files?stat_infid=000032222207
https://www.e-stat.go.jp/stat-search/files?stat_infid=000032222255
https://www.e-stat.go.jp/stat-search/files?stat_infid=000032222160
https://www.stat.go.jp/data/kokusei/2020/kekka/pdf/ug_03.pdf
https://www.stat.go.jp/data/kokusei/2020/kekka/pdf/ug_02.pdf
https://www.stat.go.jp/library/faq/faq02/faq02d03.html

CSVには5市町の全国宛先・男女別・通勤/通学の原セル参照を保存。大分市全体は佐賀関に代用しません。